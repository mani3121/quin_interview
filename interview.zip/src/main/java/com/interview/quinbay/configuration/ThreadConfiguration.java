package com.interview.quinbay.configuration;

import java.util.concurrent.ExecutorService;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ThreadConfiguration {
	
}
