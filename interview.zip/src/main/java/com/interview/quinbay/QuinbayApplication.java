package com.interview.quinbay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuinbayApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuinbayApplication.class, args);
	}

}
