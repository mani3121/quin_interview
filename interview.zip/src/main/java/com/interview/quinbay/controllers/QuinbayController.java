package com.interview.quinbay.controllers;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.interview.quinbay.model.User;
import com.interview.quinbay.service.QuinbayService;
import com.interview.quinbay.service.QuinbayThread;

@RestController
public class QuinbayController {
	
	@Autowired
	QuinbayService quinbayService;
	

	
	ExecutorService exector =Executors.newFixedThreadPool(3);
	
	@GetMapping("/api/quinbay")
	public void getUserDetails() {
		
		List<User> user=quinbayService.userDetails();
		
		for( int i=1;i<5;i++) {
			exector.execute(new QuinbayThread(i,user.get(i)));
		}
		
	}

}
