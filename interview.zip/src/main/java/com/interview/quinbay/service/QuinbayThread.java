package com.interview.quinbay.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.interview.quinbay.model.User;

public class QuinbayThread implements Runnable {


	private int id;
	private User user;
	
	public QuinbayThread(int id, User user) {
		super();
		this.id = id;
		this.user = user;
	}

	

	@Override
	public void run() {
		
		try {
			System.out.println("Start of a thread : "+id);
			System.out.println("userName :"+user.getUserName());
			System.out.println("userID :"+user.getUserId());
			System.out.println("CompanyName :"+User.companyName);
			Thread.sleep(5000);
			System.out.println("End of a thread : "+id);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
