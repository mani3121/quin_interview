package com.interview.quinbay.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.interview.quinbay.model.User;

@Service
public class QuinbayServiceImpl implements QuinbayService{

	public List<User> userDetails() {
		List<User> userList = new ArrayList<User>();
		userList.add(new User(1,"Mani"));
		userList.add(new User(2,"Vishnu"));
		userList.add(new User(3,"Mohit"));
		userList.add(new User(4,"Karthik"));
		userList.add(new User(5,"Vignesh"));
		
		return userList;
	}

}
