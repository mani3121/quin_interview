package com.interview.quinbay.service;

import java.util.List;

import com.interview.quinbay.model.User;

public interface QuinbayService {
	
	public List<User> userDetails();

}
